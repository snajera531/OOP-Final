package models;

public class Story {

    //TODO: figure out items and how the path controller will access inventory or be able to deposit items in a player's inventory
    public String item;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public final String chest = "You open the chest and see " + getItem() + " inside.\n\n";

    public final String opening = "You are from a big city and has just finished high school. They have heard of adventurers" +
            " going out to small villages and towns to help defeat monsters that have been attacking them. They have decided to go" +
            " to Montana to help with a dungeon that has been plaguing the people of Townsend. They reach Helena to start their" +
            " adventure officially.\n\n";
    public final String journeyToTownsend = "As you head down the path to Townsend, you see a silhouette in the distance.\n\n";
    public final String afterFirstFight = "You continue on your path to Townsend. After walking for a while, you reach a split " +
            "in the path.\n\n";
    public final String leftStory = "You make your way down the left path, seeing someone lying on the edge of the path. " +
            "You approach them and they give you a kind smile. \"Need some help?\" They ask. You notice that their eyes are completely white. " +
            "\"Sure.\" You respond, figuring they will offer you something simple or useless. They pull out a health potion, offering it to you.\n\n";
    public final String rightStory = "You make your way down the right path, seeing a chest a few feet away from the path. You approach the chest.\n\n";
    public final String continuedStory = "You continue down the path until seeing the path merge with the one that you chose not to go down. " +
            "You continue walking, undisturbed, until you see a small town in front of you.\n\n";
    public final String townsend = "Upon reaching Townsend, you're approached by a frantic looking villager, Taylor Park, " +
            "\"I don't care if you're not even a legit adventurer or anything, but can you please deal with the dungeon that's by my house? " +
            "Monsters keep destroying parts of my house and it's been driving me insane! I promise I'll make it worth your while if you " +
            "help me. I've still got some valuables left.\"";
    public final String helpTaylor1 = "\"Oh, thank goodness! I would deal with it myself, but I'm not really one for violence.\" " +
            "Taylor said, motioning for you to follow them. \"I'll show you where I live. The dungeon isn't too far from my house... " +
            "Though I already told you that...\" Taylor trailed off, leading you along a narrow path that cut through Townsend's more busy " +
            "part of town. You see a few homes, shops, and a small, run-down inn as you walk. \n\nOnce you leave the main part of Townsend, " +
            "you are able to see a modest wooden cabin sitting in front of a large forest. \"Here's my house! Just past where the trees start " +
            "is a huge stone arch that has a gravel path that will lead you to the dungeon. The path isn't too long, so you'll reach the " +
            "dungeon in no time.\" Taylor paused, looking anxious for a brief moment before speaking again. \"Well... good luck!\" They blurted, " +
            "darting into their home and slamming the door shut behind them. You're left in front of Taylor's house.\n\n";
    public final String keepHelping = "You turn to the forest, starting towards the trees. Once you pass through the first line of " +
            "trees, a messy gravel path appears in front of you. You continue down the path, finding the stone arch that Taylor had mentioned. " +
            "The gravel path is becoming more dense and neat as you begin to see a small, stone-brick building ahead of you. As you approach it, " +
            "you see vines growing down the sides and cracks in a few of the bricks. There is an open doorway, where you find a staircase descending " +
            "into the dungeon. There is a torch mounted on the wall just above where the staircase begins that faintly lights up the entrance. " +
            "You begin your descent into the dungeon.\n\n";
    public final String dontHelpTaylor = "\"Wait, what?\" Taylor questioned, surprised at your answer. Their expression suddenly " +
            "showed their building frustration as they turned away and stormed off. You continue walking through the town before you come across " +
            "a message board on the edge of a large clearing. You find a couple notes about villagers selling animals and other things before " +
            "seeing a quest pinned to the board. \n\n\tLooking for adventurer to defeat monster!\n\t\tReward - 2 potions\n\nMonster located in the forest to the north of town\n\n";
    public final String dontHelpTaylor2 = "You decide to leave and not enter the dungeon. You turn to leave but notice a figure standing ahead of you.\n\n";
    public final String monsterAdQuest = "You head north towards the forest mentioned in the ad. While walking, you observe some of the buildings in the " +
            "town. Upon reaching the edge of town, you see some destroyed carts and fields. Hopefully the damaged belongings have nothing to do with your " +
            "quest.\n\nYou finally reach the forest, making your way past the first line of trees when you find your monster. ";
    public final String choice2 = "After defeating the monster, you hear a grunt of frustration. You turn to see Taylor, the villager from before. " +
            "\"So you could kill this monster but you couldn't help me with the dungeon that's right by here?\" Taylor had their arms crossed, giving you a glare. " +
            "\"I'll give you one more chance to help me, but clearly I'm not a priority.\" Taylor huffed, turning their head to avoid eye contact. ";
    public final String helpTaylor2 = "Taylor's face crumbles into a look of shock. \"Wait, you'll help me? Oh, my goodness! Thank you so much!\" Taylor exclaimed. " +
            "They grab you by the wrist, leading you towards their house. \"I live just this way.\" They pointed forward to a small wooden cabin. Once in front of the cabin, " +
            "Taylor let go of your wrist, giving you a smile. \"Good luck! The dungeon is just that way.\" Taylor pointed towards the forest, before darting into their cabin. \n\n";
    public final String dontHelpEnd = "You realize that the adventurer life isn't really the life you want to live. You exit Townsend, " +
            "heading for Helena to hop on a plane back home to live a boring life.\n\n";
    public final String turnRight = "You turn right. ";
    public final String turnLeft = "You turn left. ";
    public final String walkStraight = "You walk straight. ";
}
