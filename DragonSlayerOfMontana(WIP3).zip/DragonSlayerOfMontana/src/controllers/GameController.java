package controllers;

import models.Inventory;
import models.Story;

import lib.ConsoleIO;
import models.classes.Character;
import models.classes.Thief;
import models.classes.Warrior;
import models.classes.Wizard;

public class GameController {
    PathController pc = new PathController();
    CombatController cc = new CombatController();
    MonsterFactory mf = new MonsterFactory();
    Story s = new Story();
    boolean gameOver = false;
    Character player = new Character();

    public void run(){
        createCharacter();
        do {
            gameStart();
            if(!gameOver){
                dungeon1();
            }
        } while(!gameOver);
    }

    public Character createCharacter(){
        String greeting = "Welcome to the Dungeon Slayer of Montana!";
        Inventory inventory = new Inventory();
        String[] characterClass = {"Warrior", "Wizard", "Thief"};
        if(ConsoleIO.promptForBoolean("Would you like to create a character and play the game or exit the game? (y/n) ", "y", "n")){
            switch(ConsoleIO.promptForMenuSelection(characterClass, true)){
                case 1:
                    player = new Warrior(ConsoleIO.promptForString("Please, name your character: "), 30, 30, 0, 0, inventory, 15, 15, 15);
                    break;
                case 2:
                    player = new Wizard(ConsoleIO.promptForString("Please, name your character: "), 30, 30, 0, 0, inventory, 15, 15, 15);
                    break;
                case 3:
                    player = new Thief(ConsoleIO.promptForString("Please, name your character: "), 30, 30, 0, 0, inventory, 15, 15, 15);
                    break;
                default:
                    System.out.println("There was an issue. Please, try again.");

            }
        }
        return player;
    }

    public void gameStart(){
        pc.startOfStory();
        if(!cc.encounter(mf.createEasy())){
           gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else {
            pc.afterFirstFight();
            pc.enteringTownsend();
        }
    }

    public void dungeon1(){
        System.out.print("You enter the dungeon and go down the stairs. ");
        System.out.print(s.walkStraight);
        enterRoom();
        System.out.print(s.turnRight + s.walkStraight);
        if(!cc.encounter(mf.createEasy())){
            gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else {
            System.out.print(s.turnLeft + s.turnLeft);
            System.out.print("You enter a room to continue moving through the dungeon. ");
            pc.chest(player);
            System.out.print("You exit the room through the door you have yet to go through. ");
            System.out.print(s.turnRight);
            if(!cc.encounter(mf.createEasy())){
                gameOver = true;
                System.out.println("\n~~GAME OVER~~\n\n");
            } else {
                System.out.println(s.turnLeft);
                System.out.print("You enter a room to continue moving through the dungeon. ");
                pc.chest(player);
                System.out.println("You exit the room through the door you have yet to go through. ");
                System.out.print(s.walkStraight);
                if(!cc.encounter(mf.createEasy())){
                    gameOver = true;
                    System.out.println("\n~~GAME OVER~~\n\n");
                } else {
                    System.out.println();
                }
            }
        }
    }

    public void dungeon2(){

    }

    public void dungeon3(){

    }

    public void mamaBattle(){

    }

    public void enterRoom(){
        if(ConsoleIO.promptForBoolean("Would you like to enter the room in front of you? (y/n) ", "y", "n")){
            pc.chest(player);
        } else{
            System.out.println("You decide not to enter the room.\n\n");
        }
    }
}
