package controllers;

import models.Inventory;
import models.Story;

import lib.ConsoleIO;
import models.classes.Character;
import models.classes.Thief;
import models.classes.Warrior;
import models.classes.Wizard;

public class GameController {
    PathController pc = new PathController();
    CombatController cc = new CombatController();
    MonsterFactory mf = new MonsterFactory();
    Story s = new Story();
    boolean gameOver = false;
    Character player = new Character();

    public void run(){
        createCharacter();
        do {
            gameStart();
            dungeon1();
            dungeon2();
            dungeon3();
            mamaBattle();
        } while(!gameOver);
    }

    public Character createCharacter(){
        String greeting = "Welcome to the Dungeon Slayer of Montana!";
        Inventory inventory = new Inventory();

        String[] characterClass = {"Warrior", "Wizard", "Thief"};
        if(ConsoleIO.promptForBoolean("Would you like to create a character and play the game or exit the game? (y/n) ", "y", "n")){
            switch(ConsoleIO.promptForMenuSelection(characterClass, true)){
                case 1:
                    player = new Warrior();
                    player.setName(ConsoleIO.promptForString("Please, name your character: "));
                    break;
                case 2:
                    player = new Wizard();
                    player.setName(ConsoleIO.promptForString("Please, name your character: "));
                    break;
                case 3:
                    player = new Thief();
                    player.setName(ConsoleIO.promptForString("Please, name your character: "));
                    break;
                default:
                    System.out.println("There was an issue. Please, try again.");

            }
        }
        return player;
    }

    public void gameStart(){
        pc.startOfStory();
        if(!cc.encounter(player, mf.createEasy())){
           gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else {
            pc.afterFirstFight();
            pc.enteringTownsend();
        }
    }

    public void dungeon1(){
        System.out.print("You enter the dungeon and go down the stairs. ");
        System.out.print(s.walkStraight);
        enterChestRoom();
        System.out.print(s.turnRight + s.walkStraight);
        if(!cc.encounter(player, mf.createEasy())){
            gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else {
            System.out.print(s.turnLeft + s.turnLeft);
            System.out.print("You enter a room to continue moving through the dungeon. ");
            pc.chest(player);
            System.out.print("You exit the room through the door you have yet to go through. ");
            System.out.print(s.turnRight);
            if(!cc.encounter(player, mf.createEasy())){
                gameOver = true;
                System.out.println("\n~~GAME OVER~~\n\n");
            } else {
                System.out.println(s.turnLeft);
                System.out.print("You enter a room to continue moving through the dungeon. ");
                pc.chest(player);
                System.out.println("You exit the room through the door you have yet to go through. ");
                System.out.print(s.walkStraight);
                if(!cc.encounter(player, mf.createEasy())){
                    gameOver = true;
                    System.out.println("\n~~GAME OVER~~\n\n");
                } else {
                    System.out.print(s.turnRight + s.walkStraight);
                    enterChestRoom();
                    System.out.print(s.turnLeft + s.walkStraight);
                    enterChestRoom();
                    System.out.print(s.turnLeft);
                    System.out.println("You found the stairs! You head down the stairs into the second floor of the dungeon.\n\n");
                }
            }
        }
    }

    public void dungeon2(){
        System.out.println(s.walkStraight);
        if(!cc.encounter(player, mf.createMedium())){
            gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else{
            enterChestRoom();
            System.out.println(s.turnRight + s.walkStraight + s.turnRight + s.walkStraight);
            if(!cc.encounter(player, mf.createMedium())){
                gameOver = true;
                System.out.println("\n~~GAME OVER~~\n\n");
            } else{
                enterChestRoom();
                System.out.println(s.turnLeft + s.walkStraight);
                enterMonsterRoom();
                if(!cc.encounter(player, mf.createMedium())){
                    gameOver = true;
                    System.out.println("\n~~GAME OVER~~\n\n");
                } else{
                    System.out.print(s.turnLeft + s.walkStraight + s.turnRight);
                    System.out.println("There are two rooms!");
                    enterChestRoom();
                    enterChestRoom();
                    System.out.println(s.walkStraight + s.turnRight);
                    System.out.println("You found the stairs! You head down the stairs to continue to the third floor of the dungeon.\n\n");
                }
            }
        }
    }

    public void dungeon3(){
        System.out.print(s.turnLeft + s.walkStraight);
        enterChestRoom();
        System.out.print(s.turnLeft + s.walkStraight + s.turnRight + s.walkStraight);
        if(!cc.encounter(player, mf.createHard())){
            gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else{
            enterChestRoom();
            System.out.print(s.walkStraight + s.turnRight);
            enterChestRoom();
            System.out.print(s.turnLeft + s.walkStraight + s.turnRight + s.walkStraight);
            if(!cc.encounter(player, mf.createHard())){
                gameOver = true;
                System.out.println("\n~~GAME OVER~~\n\n");
            } else{
                System.out.print(s.walkStraight);
                enterChestRoom();
                System.out.print(s.turnRight + s.walkStraight);
                if(!cc.encounter(player, mf.createHard())){
                    gameOver = true;
                    System.out.println("\n~~GAME OVER~~\n\n");
                } else{
                    System.out.print(s.turnRight + s.walkStraight);
                    enterChestRoom();
                    System.out.print(s.turnLeft + s.walkStraight);
                    enterChestRoom();
                    if(!cc.encounter(player, mf.createHard())){
                        gameOver = true;
                        System.out.println("\n~~GAME OVER~~\n\n");
                    } else{
                        System.out.print(s.turnLeft);
                        System.out.println("You found the stairs! You head down the stairs to the final floor of the dungeon.\n\n");
                    }
                }
            }
        }
    }

    public void mamaBattle(){
        System.out.print(s.walkStraight + "There are two rooms!");
        enterChestRoom();
        enterChestRoom();
        System.out.println("You walk around the corner, seeing gold coins in giant piles in the room in front of you " +
                "As you enter the room, you turn to see more massive piles of gold coins. Suddenly the room shakes... \n\n");
        if(!cc.encounter(player, mf.createBoss())){
            gameOver = true;
            System.out.println("\n~~GAME OVER~~\n\n");
        } else{
            System.out.println("You won the game!!! You have defeated Mama Dragon (and her minions and child(ren)). Congratulations!\n\n");
        }
    }

    public void enterChestRoom(){
        if(ConsoleIO.promptForBoolean("Would you like to enter the room in front of you? (y/n) ", "y", "n")){
            pc.chest(player);
        } else{
            System.out.println("You decide not to enter the room.\n\n");
        }
    }

    public void enterMonsterRoom(){
        if(ConsoleIO.promptForBoolean("Would you like to enter the room in front of you? (y/n) ", "y", "n")){
            if(!cc.encounter(player, mf.createMedium())) {
                gameOver = true;
                System.out.println("\n~~GAME OVER~~\n\n");
            }
        } else{
            System.out.println("You decide not to enter the room.\n\n");
        }
    }
}
