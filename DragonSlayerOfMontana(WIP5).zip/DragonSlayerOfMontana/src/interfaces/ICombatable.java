package interfaces;

public interface ICombatable {
    int attack(int roll);
}
