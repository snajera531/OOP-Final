package models;

public class Inventory {
}
