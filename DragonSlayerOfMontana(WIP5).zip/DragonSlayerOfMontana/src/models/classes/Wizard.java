package models.classes;

import interfaces.ICombatable;

public class Wizard extends Character implements ICombatable {
    private int intel = 15;
    private int pow = 15;
    private int wit = 15;

    public Wizard() {
        setName(getName());
        setHp(getHp());
        setCurHp(getCurHp());
        setExp(getExp());
        setHPots(getHPots());
        setMPots(getMPots());
        setIntel(getIntel());
        setPow(getPow());
        setWit(getWit());
    }

    public int getIntel() {
        return intel;
    }

    public void setIntel(int intel) {
        this.intel = intel;
    }

    public int getPow() {
        return pow;
    }

    public void setPow(int pow) {
        this.pow = pow;
    }

    public int getWit() {
        return wit;
    }

    public void setWit(int wit) {
        this.wit = wit;
    }

    @Override
    public String toString() {
        return "Wizard{ " + super.toString() +
                "intel=" + getIntel() +
                ", pow=" + getPow() +
                ", wit=" + getWit();
    }

    @Override
    public int attack(int dmg) {
        dmg = roll(2, 14);
        int statBuff = dmg + getExp() / 10 * 2;
        return statBuff+getWit();
    }
}