package models.classes;

import interfaces.ICombatable;

public class Warrior extends Character implements ICombatable {
    private int str = 15;
    private int atk = 15;
    private int grit = 15;

    public Warrior() {
        setName(getName());
        setHp(getHp());
        setCurHp(getCurHp());
        setExp(getExp());
        setHPots(getHPots());
        setMPots(getMPots());
        setStr(getStr());
        setAtk(getAtk());
        setGrit(getGrit());
    }

    public int getStr() {
        return str;
    }

    public void setStr(int str) {
        this.str = str;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = atk;
    }

    public int getGrit() {
        return grit;
    }

    public void setGrit(int grit) {
        this.grit = grit;
    }

    @Override
    public String toString() {
        return "Warrior{" +
                "str=" + getStr() +
                ", atk=" + getAtk() +
                ", grit=" + getGrit();
    }

    @Override
    public int attack(int roll) {
        roll = roll(3, 9);
        int statBuff = roll + getExp() / 10 * 2;
        return statBuff + getGrit();
    }
}


