package models.monsters;

public enum MonsterName {
    SLIME,
    SKELETON,
    ZOMBIE,
    GHOST,
    WOLF,
    VAMPIRE,
    OGRE,
    MINOTAUR,
    BABY_DRAGON,
    MAMA_DRAGON
}
