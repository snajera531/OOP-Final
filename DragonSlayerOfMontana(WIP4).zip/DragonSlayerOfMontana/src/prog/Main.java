package prog;

import controllers.GameController;
import models.Story;

import java.awt.*;

public class Main {

    public static void main(String[] args) {
        new GameController().run();
    }
}
