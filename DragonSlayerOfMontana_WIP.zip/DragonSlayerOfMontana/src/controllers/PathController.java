package controllers;

import models.Story;

public class PathController {
    Story s  = new Story();

    public void opening(){

    }

    public void dungeon1(){

    }

    public void dungeon2(){

    }

    public void dungeon3(){

    }

    public void mamaBattle(){

    }
}
