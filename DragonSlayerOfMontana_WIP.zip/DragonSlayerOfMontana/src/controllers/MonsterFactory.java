package controllers;

public class MonsterFactory {
}
