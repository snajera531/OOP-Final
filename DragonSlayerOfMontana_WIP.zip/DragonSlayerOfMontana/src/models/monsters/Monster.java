package models.monsters;

public class Monster {
}
