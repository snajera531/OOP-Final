package models.monsters;

public class Minotaur {
}
