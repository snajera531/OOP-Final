package models.monsters;

public class Vampire {
}
