package models.monsters;

public class Ghost {
}
