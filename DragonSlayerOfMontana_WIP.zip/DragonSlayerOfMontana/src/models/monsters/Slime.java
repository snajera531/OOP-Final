package models.monsters;

public class Slime {
}
