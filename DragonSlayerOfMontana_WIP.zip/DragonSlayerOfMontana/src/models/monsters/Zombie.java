package models.monsters;

public class Zombie {
}
