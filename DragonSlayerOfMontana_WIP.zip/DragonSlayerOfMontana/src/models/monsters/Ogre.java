package models.monsters;

public class Ogre {
}
