package models.monsters;

public class Skeleton {
}
