package models.monsters;

public class Wolf {
}
