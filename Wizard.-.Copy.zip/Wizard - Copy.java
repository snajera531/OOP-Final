package models;

import interfaces.ICombatable;

public class Wizard extends Character implements ICombatable {
    private int intel;
    private int pow;
    private int wit;

    public Wizard(int intel, int pow, int wit) {
        this.intel = getIntel();
        this.pow = getPow();
        this.wit = getWit();
    }

    public int getIntel() {
        return intel;
    }

    public void setIntel(int intel) {
        this.intel = intel;
    }

    public int getPow() {
        return pow;
    }

    public void setPow(int pow) {
        this.pow = pow;
    }

    public int getWit() {
        return wit;
    }

    public void setWit(int wit) {
        this.wit = wit;


    }

    @Override
    public String toString() {
        return "Thief " +
                "intel=" + getIntel() +
                ", pow=" + getPow() +
                ", wit=" + getWit();
    }

    @Override
    public int attack(int roll) {
        roll = roll(2, 14);
        int statBuff = roll + getExp() / 10 * 2;
        return statBuff+getWit();
    }

    @Override
    public int accuracy(int roll) {
        roll = roll(1,20);
        return roll;
    }
}
